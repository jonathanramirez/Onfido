//
//  Onfido.h
//
//  Copyright © 2016-2024 Onfido. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Onfido.
FOUNDATION_EXPORT double OnfidoVersionNumber;

//! Project version string for Onfido.
FOUNDATION_EXPORT const unsigned char OnfidoVersionString[];

